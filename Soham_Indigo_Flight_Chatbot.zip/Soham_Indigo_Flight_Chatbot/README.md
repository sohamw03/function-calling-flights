
# Pre-requisites

1. Made with Python 3.11.5
2. `.env` file with the following variables:
```
OPENAI_API_KEY="" # https://openai.com
SKY_SCANNER_API_KEY="" # https://rapidapi.com/ntd119/api/sky-scanner3
HUGGINGFACEHUB_API_TOKEN="" # https://huggingface.co
```

# Installation

1. Create a virtual environment using the following command:
```bash
python -m venv env
```

2. Activate the virtual environment using the following command:
```bash
source env/bin/activate # For Linux
env\Scripts\activate # For Windows
```

3. Install the required packages using the following command:
```bash
pip install -r requirements.txt
```

4. Run the following command to start the chatbot:
```bash
cd langchain_system
python chat.py
```

# Author
- Soham Waghmare